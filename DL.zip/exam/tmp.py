import json

if __name__ == '__main__':
    pass
    # with open('./dataset/mappings.json') as f:
    #     mappings = json.load(f)
    # meta_len = sum(map(len, mappings))
    # biases = [0, *map(len, mappings[:-1])]
    # biasums = [sum(biases[:i+1]) for i in range(len(biases))]
    #
    # with open('./dataset/training_set.csv', 'r') as f:
    #     lines = [line.split(',') for line in f.readlines()]
    # meta = []
    # for line in lines[1:-1]:
    #     tmp = [0] * meta_len
    #     for i in range(len(mappings)):
    #         sec_index = mappings[i][line[i+1]]
    #         if sec_index == -1:
    #             continue
    #         index = mappings[i][line[i+1]] + biasums[i]
    #         tmp[index] = 1
    #     meta.append(tmp)
    #
    # for item in meta:
    #     print(item)
