from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
# from torchstat import stat

import torch.nn as nn
from torch import Tensor, randn, cat

class CNN_baseline(nn.Module):
    def __init__(self, n_channels=3, n_classes=2):
        """
        Initializes CNN object.

        Args:
            n_channels: number of input channels
            n_classes: number of classes of the classification problem
        """
        super().__init__()
        self.conv_layers = nn.Sequential(
            nn.Conv2d(n_channels, 32, 4, 2, 1),
            nn.BatchNorm2d(32),
            nn.ReLU(),
            # 64*64
            nn.Conv2d(32, 48, 4, 2, 1),
            nn.BatchNorm2d(48),
            nn.ReLU(),
            # 32*32

            nn.Conv2d(48, 64, 4, 2, 1),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            # 16*16

            nn.Conv2d(64, 128, 4, 2, 1),
            nn.BatchNorm2d(128),
            nn.ReLU(),
            # 8*8

            nn.Conv2d(128, 192, 4, 2, 1),
            nn.BatchNorm2d(192),
            nn.ReLU(),
            # 4 * 4
            nn.Conv2d(192, 256, 4, 2, 1),
            nn.BatchNorm2d(256),
            nn.ReLU(),
            # 2 * 2
        )

        self.FC = nn.Sequential(
            nn.Linear(1024, 256),
            nn.ReLU(),
            nn.Linear(256, n_classes),
        )

    def forward(self, x):
        """
        Performs forward pass of the input.
        Args:
            x: input to the network
        Returns:
            out: outputs of the network
        """
        if not isinstance(x, Tensor):
            x = Tensor(x)
        tmp = self.conv_layers(x)
        return self.FC(tmp.view(-1, 1024))


class CNN_with_meta(nn.Module):
    def __init__(self, meta_len=34, n_channels=3, n_classes=2):
        """
        Initializes CNN object.

        Args:
            n_channels: number of input channels
            n_classes: number of classes of the classification problem
        """
        super().__init__()
        self.image_path = nn.Sequential(
            nn.Conv2d(n_channels, 32, 4, 2, 1),
            nn.BatchNorm2d(32),
            nn.ReLU(),
            # 64*64
            nn.Conv2d(32, 48, 4, 2, 1),
            nn.BatchNorm2d(48),
            nn.ReLU(),
            # 32*32

            nn.Conv2d(48, 64, 4, 2, 1),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            # 16*16

            nn.Conv2d(64, 128, 4, 2, 1),
            nn.BatchNorm2d(128),
            nn.ReLU(),
            # 8*8

            nn.Conv2d(128, 192, 4, 2, 1),
            nn.BatchNorm2d(192),
            nn.ReLU(),
            # 4 * 4
            nn.Conv2d(192, 256, 4, 2, 1),
            nn.BatchNorm2d(256),
            nn.ReLU(),
            # 2 * 2
        )

        self.meta_path = nn.Sequential(
            nn.Linear(meta_len, 256),
            nn.ReLU(),
            nn.Linear(256, 256),
            nn.ReLU()
        )

        self.FC = nn.Sequential(
            nn.Linear(1280, 256),
            nn.ReLU(),
            nn.Linear(256, n_classes),
        )

    def forward(self, x1, x2):
        """
        Performs forward pass of the input.
        Args:
            x: input to the network
        Returns:
            out: outputs of the network
        """
        if not isinstance(x1, Tensor):
            x1 = Tensor(x1)
        if not isinstance(x2, Tensor):
            x2 = Tensor(x2)
        conv_out = self.image_path(x1).view(-1, 1024)
        meta_out = self.meta_path(x2)
        return self.FC(cat((conv_out, meta_out), dim=1))


if __name__ == '__main__':
    a = randn(3, 4)  # 随机生成一个shape（3，4）的tensor
    b = randn(3, 5)  # 随机生成一个shape（2，4）的tensor

    print(cat([a, b], dim=1).size())
