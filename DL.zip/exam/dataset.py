from torch.utils.data import Dataset
from torch import Tensor
from PIL import Image
import json


def load_image(path):
    img = Image.open(path)
    img.load()
    return img


class BaseDataset(Dataset):
    def __init__(self, transforms, train=True):
        fmt = './dataset/'
        fmt += 'train' if train else 'validation'
        fmt += '_set_128/img_%d.jpg'

        if train:
            self.data = [load_image(fmt % i) for i in range(1, 748 + 1)]
            with open('./dataset/training_set.csv', 'r') as f:
                lines = [line.split(',') for line in f.readlines()]
            self.labels = [int(row[-1].strip()) for row in lines[1:-1]]
            assert len(self.data) == len(self.labels)
        else:
            self.data = [load_image(fmt % i) for i in range(1, 186 + 1)]
            with open('./dataset/validation_set.csv', 'r') as f:
                lines = [line.split(',') for line in f.readlines()]
            self.labels = [int(row[-1].strip()) for row in lines[1:-1]]
            assert len(self.data) == len(self.labels)

        self.transforms = transforms
        print('train set' if train else 'validation set', end=' ')
        print('initialized')

    def __getitem__(self, item):
        return self.transforms(self.data[item]), self.labels[item]

    def __len__(self):
        return len(self.data)



class MetaDataset(Dataset):
    def __init__(self, transforms, train=True):
        fmt = './dataset/'
        fmt += 'train' if train else 'validation'
        fmt += '_set_128/img_%d.jpg'

        if train:
            self.data = [load_image(fmt % i) for i in range(1, 748 + 1)]
            with open('./dataset/training_set.csv', 'r') as f:
                lines = [line.split(',') for line in f.readlines()]
            self.labels = [int(row[-1].strip()) for row in lines[1:]]
        else:
            self.data = [load_image(fmt % i) for i in range(1, 186 + 1)]
            with open('./dataset/validation_set.csv', 'r') as f:
                lines = [line.split(',') for line in f.readlines()]
            self.labels = [int(row[-1].strip()) for row in lines[1:]]
        self.meta = MetaDataset.get_meta(lines)
        assert len(self.data) == len(self.meta) == len(self.labels)

        self.transforms = transforms
        print('train set' if train else 'validation set', end=' ')
        print('initialized')

    @staticmethod
    def get_meta(lines):
        with open('./dataset/mappings.json') as f:
            mappings = json.load(f)
        meta_len = sum(map(len, mappings))
        biases = [0, *map(len, mappings[:-1])]
        biasums = [sum(biases[:i + 1]) for i in range(len(biases))]

        meta = []
        for line in lines[1:]:
            tmp = [0] * meta_len
            for i in range(len(mappings)):
                sec_index = mappings[i][line[i + 1]]
                if sec_index == -1:
                    continue
                index = mappings[i][line[i + 1]] + biasums[i]
                tmp[index] = 1
            meta.append(tmp)
        return meta

    def __getitem__(self, item):
        return self.transforms(self.data[item]), Tensor(self.meta[item]), self.labels[item]

    def __len__(self):
        return len(self.data)

