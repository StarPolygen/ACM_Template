from PIL import Image
import json


def pre_resize():
    for i in range(1, 748+1):

        img = Image.open('./dataset/Training_set/img_%d.jpg' % i)

        out = img.resize((128, 128))

        out.save('./dataset/train_set_128/img_%d.jpg' % i)

    for i in range(1, 186+1):
        img = Image.open('./dataset/Validation_set/img_%d.jpg' % i)

        out = img.resize((128, 128))

        out.save('./dataset/validation_set_128/img_%d.jpg' % i)


def build_mappings():
    mappings = [{} for _ in range(5)]

    def add_file(filename):
        with open(filename) as f:
            lines = [line.split(',') for line in f.readlines()[1:]]
        for line in lines:
            for i in range(5):
                key = line[i + 1]
                if not key in mappings[i].keys():
                    if key == '':
                        mappings[i][key] = -1
                        continue
                    tmp = len(mappings[i].keys())
                    mappings[i][key] = tmp

    add_file('./dataset/training_set.csv')
    add_file('./dataset/validation_set.csv')
    with open('./mappings.json', 'w') as f1:
        json.dump(mappings, f1)


if __name__ == '__main__':
    pre_resize()
    build_mappings()
