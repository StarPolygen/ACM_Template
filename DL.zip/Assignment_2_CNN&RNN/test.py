import torch
from torch.nn import CrossEntropyLoss
# from torchstat import stat
from pytorch_mlp import MLP
import numpy as np
import time
from torch import nn
loss_func = CrossEntropyLoss()

x = torch.tensor([[-1.0,1.0]])
y = torch.tensor([0])
print(loss_func(x, y))

x = torch.tensor([[-1.0,1.0]])
softmax = nn.Softmax(dim=1)
x = softmax(x)
y = torch.tensor([0])

print(loss_func(x, y))
# wGrads = torch.tensor([[0.1, 0.2, 0.7], [0.3, -0.4, 0.2]])
# labels = torch.tensor([[1,1,2],[1,2,3]])
# print(torch.zeros([labels.shape[0], 10]), labels[:, 0])
# time.sleep(0.3)
# print(torch.zeros([labels.shape[0], 10]).scatter(1, labels[:, 0].view(-1, 1), 1))

# bGrads = torch.tensor([0.5,0.5])
# pGrads = torch.cat([wGrads, bGrads.view(-1, 1)], dim=1)
# print(pGrads)
# grad_sum = sum(pGrads)/wGrads.shape[0]
# print(grad_sum)
# magnitude = sum(grad_sum**2)
# print(magnitude)

# loss_func = CrossEntropyLoss()
#
# output = torch.tensor([[0.1,0.2,0.7]])
# print(output.size()[0])
# labels = torch.tensor([2])
# a = loss_func(output, labels).item()
# print(a)
#
# output = torch.tensor([[0.2,0.2,0.6]])
# labels = torch.tensor([0])
# b = loss_func(output, labels).item()
# print(b)
#
# output = torch.tensor([[0.1,0.2,0.7],[0.2,0.2,0.6]])
# labels = torch.tensor([2,0])
# print((a+b)/2, loss_func(output, labels).item())

# print(output.topk(1, 1)[1])
# if output[0][1] == output[1][0]:
#     print(True)
# if output[0][0] != output[1][0]:
#     print(False)