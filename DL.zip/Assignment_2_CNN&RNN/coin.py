import random
import argparse

DEFAULT_ITER = 1_000_000
FLAG = None


def coin():
    return 1 if random.random() >= 0.5 else 0


def multitoss():
    cnt = 0
    for i in range(FLAGS.num_iter):
        if coin() == 1:
            cnt += 1

    print("DEFAULT_ITER = %d" % (FLAGS.num_iter))
    print("P(head) = %f" % (cnt / FLAGS.num_iter))


if __name__ == '__main__':
    # Command line arguments
    parser = argparse.ArgumentParser()
    parser.add_argument('--num_iter',
                        type=int,
                        default=DEFAULT_ITER,
                        help='num_iter')

    FLAGS, unparsed = parser.parse_known_args()
    multitoss()
