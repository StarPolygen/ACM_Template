# READ ME

All the curves have been drawn already. You can find them in the direction "figures". The explaining of them can be find in the report. 

#### Part I: pytorch MLP

​	Run the code "Part 1/pytorch_train_mlp.py" to train a MLP on the dataset that used in Assignment1. If you want train a MLP on CIFAR10, run "Part 2/train_MLP_CIFAR10".

#### Part II

​	To train a CNN on CIFAR10, please run "Part 2/cnn_train.py"

​	Some explaining of running configurations are as follow:

| Name in cmd       | type  | description                                         |
| ----------------- | ----- | --------------------------------------------------- |
| data_augmentation | bool  | Use data augmentation or not                        |
| weight_penal      | float | Parameter of L2 regularization                      |
| threads           | int   | How many sub threads will be used to for dataloader |
| using_gpu         | bool  | Using GPU or not                                    |

#### Part III

​	To train a RNN, run "Part 2/train.py"

| Name in cmd    | type | description                                                  |
| -------------- | ---- | ------------------------------------------------------------ |
| validate_times | int  | Sample how many batches to compute accuracy. The dataset is a random generator, so only one batch may be too little. |
| num_workers    | int  | How many sub threads will be used to for dataloader. This parameter will be fill in constructor method of dataloader. |
| using_gpu      | bool | Using GPU or not                                             |

**If you run the code, you will get different result of the results in report. Because I find that Cross Entropy loss in pytorch will invoke the softmax automatically, so my original code will invoke softmax twice. I modified it at last but have no time to run the codes again. It does not has great influence on the accuracy but will make the absolute value of loss lower.  Also makes the speed of train different.**