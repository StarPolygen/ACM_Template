import matplotlib.pyplot as plt
import json
import numpy as np

if __name__ == '__main__':
    # with open('accu_len_5_30_2.json', 'r') as f:
    #     accu_data = json.load(f)
    # plt.figure(figsize=(9.6, 3.2))
    # plt.plot(range(5, 30, 2), accu_data, '-b')
    # plt.title('accuracy respect to input length')
    # plt.show()
    with open('loss_without_clip.json', 'r') as f:
        loss_data = json.load(f)
    with open('grad_without_clip.json', 'r') as f:
        grads_data = np.array(json.load(f))

    _, ax1 = plt.subplots(figsize=(24, 6))
    ax2 = ax1.twinx()

    ax1.set_xlabel("Epoch")
    ax1.set_ylabel("Loss")
    ax2.set_ylabel("Gradient")
    ax2.set_yscale('log')
    ax2.set_adjustable("datalim")

    ax1.plot(range(1, 10000, 5), loss_data, color='gold', linestyle='-')
    ax2.plot(range(1, 10000, 5), grads_data, 'r-')
    plt.show()

