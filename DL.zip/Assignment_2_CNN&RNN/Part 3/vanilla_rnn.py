from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import torch
import torch.nn as nn
import time

class VanillaRNN(nn.Module):

    def __init__(self, seq_length, hidden_dim, output_dim, input_dim=1):
        super(VanillaRNN, self).__init__()
        self.len = seq_length
        self.n_out = output_dim
        self.n_hidden = hidden_dim
        self.hidden = nn.Sequential(
            nn.Linear(10*input_dim + hidden_dim, hidden_dim),
            nn.Tanh()
        )
        self.output = nn.Linear(hidden_dim, output_dim)
        # Initialization here ...

    def forward(self, x):
        # x will be a 2 dimension vector of shape (batch_size, seq_length-1)
        assert x.size()[1] == self.len
        H = torch.tensor([[0.0]*self.n_hidden for _ in range(x.shape[0])])
        if x.is_cuda:
            H = H.cuda()
        for i in range(self.len):
            x_one_hot = torch.zeros([x.shape[0], 10])
            if x.is_cuda:
                x_one_hot = x_one_hot.cuda()
            x_one_hot.scatter(1, x[:, i].view(-1, 1).long(), 1)
            h_in = torch.cat([x_one_hot, H], dim=1)
            H = self.hidden(h_in)
        return self.output(H)

    def getGradsMagnitude(self):
        '''
        :return: L2 Norm of all the parameters in the RNN.
            Because the vectors of different parameters' gradients have no Overlapping,
            these vectors are perpendicular to each other. Therefore, the total L2 norm can be:
                (Sum(norm^2))^0.5
        '''
        total_norm = 0
        for p in self.parameters():
            param_norm = p.grad.data.norm(2)
            total_norm += param_norm.item() ** 2
        return total_norm ** 0.5
    # # add more methods here if needed

if __name__ == '__main__':
    rnn = VanillaRNN(5, 20, 10)
    a = torch.rand(8, 5)
    print(rnn(a))
