from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import argparse
import time
import numpy as np
import torch
from torch.optim.rmsprop import RMSprop
from torch.nn import CrossEntropyLoss
from torch.utils.data import DataLoader
from dataset import PalindromeDataset
from vanilla_rnn import VanillaRNN
import json

# result_path = ''


def validate(model, X, Y):
    total = 0
    correct = 0
    output = model(X)
    labels = output.topk(1, 1)[1].squeeze()
    for i in range(len(labels)):
        if labels[i] == Y[i]:
            correct += 1
        total += 1
    return float(correct/total)

def train(config):
    start_time = time.time()
    # Initialize the model that we are going to use
    model = VanillaRNN(config.input_length,  config.num_hidden, config.num_classes)
    if config.using_gpu:
        model = model.cuda()

    # Initialize the dataset and data loader (leave the +1)
    dataset = PalindromeDataset(config.input_length+1)
    data_loader = DataLoader(dataset, config.batch_size, num_workers=config.num_workers)

    # Setup the loss and optimizer
    # criterion = None  # fixme
    loss_func = CrossEntropyLoss()
    optimizer = RMSprop(params=model.parameters(), lr=config.learning_rate)

    min_loss = 100.0
    max_accu = 0
    # loss_data = []
    # grads_data = []
    grads_queue = []
    mean_grad = 0.0

    step = 0
    time_remain = config.validate_times
    accu = 0
    for X, Y in data_loader:
        if config.using_gpu:
            X = X.cuda()
            Y = Y.cuda()
        optimizer.zero_grad()
        output = model(X)
        loss = loss_func(output, Y)
        min_loss = min(min_loss, loss.item())
        loss.backward()

        grad = model.getGradsMagnitude()
        if len(grads_queue) > grad_mem:
            mean_grad -= grads_queue[0]/grad_mem
            grads_queue.pop(0)
            grad = min(grad, 4*mean_grad)
        torch.nn.utils.clip_grad_norm(model.parameters(), max_norm=4*mean_grad)

        grads_queue.append(grad)
        mean_grad += grads_queue[-1]/grad_mem

        optimizer.step()

        if not (step+1) % config.eval_freq:
            if time_remain:
                accu += validate(model, X, Y)
                time_remain-=1
                continue
            else:
                accu /= config.validate_times
                max_accu = max([max_accu, accu])
                print('Epoch{:d}, loss={:.6f}, gradients={:.6f}, Accuracy = {:.2f}%'.format(
                    step+1, loss.item(), model.getGradsMagnitude(), accu*100))
                time_remain = config.validate_times
                accu = 0.0

        step += 1
        if step == config.train_steps or max_accu > 1.0 - 1e-4:
            break

    print('Done training. Min loss:%.6f, Max Accuracy: %.2f%%, Time%.1fs'
          % (min_loss, max_accu*100, time.time()-start_time))
    return max_accu

def experiment():
    prev_accu = 0
    accus = []
    for i in range(5, 30, 2):
        print('================Start training length %d================' % i)
        config.input_length = i
        accu = train(config)
        retry = 3
        while accu < 0.5 *prev_accu and retry:
            accu = max(accu, train(config))
            retry -= 1
        accus.append(accu)
        prev_accu = accus[-1]

    with open('accu_len_5_30_2.json', 'w') as f:
        json.dump(accus, f)


if __name__ == "__main__":

    # Parse training configuration
    parser = argparse.ArgumentParser()

    # Model params
    parser.add_argument('--input_length', type=int, default=10, help='Length of an input sequence')
    parser.add_argument('--input_dim', type=int, default=1, help='Dimensionality of input sequence')
    parser.add_argument('--num_classes', type=int, default=10, help='Dimensionality of output sequence')
    parser.add_argument('--num_hidden', type=int, default=128, help='Number of hidden units in the model')
    parser.add_argument('--batch_size', type=int, default=128, help='Number of examples to process in a batch')
    parser.add_argument('--learning_rate', type=float, default=1e-4, help='Learning rate')
    parser.add_argument('--train_steps', type=int, default=10000, help='Number of training steps')
    parser.add_argument('--eval_freq', type=int, default=20)
    parser.add_argument('--using_gpu', type=bool, default=False)
    parser.add_argument('--num_workers', type=int, default=16)
    parser.add_argument('--validate_times', type=int, default=20,
                        help='Sample how many batches to compute the accuracy of rnn, one batch may too small')

    grad_mem = 50
    config = parser.parse_args()
    # Train the model
    # experiment()
    train(config)