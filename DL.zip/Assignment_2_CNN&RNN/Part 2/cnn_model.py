from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import torch.nn as nn
from torch import Tensor

class CNN(nn.Module):
    def __init__(self, n_channels, n_classes):
        """
        Initializes CNN object.

        Args:
            n_channels: number of input channels
            n_classes: number of classes of the classification problem
        """
        super().__init__()
        self.convLayers = nn.Sequential(
            nn.Conv2d(n_channels, 64, 3, 1, 1),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.MaxPool2d(3, 2, 1),
            # nn.Dropout2d(dropout),

            nn.Conv2d(64, 128, 3, 1, 1),
            nn.BatchNorm2d(128),
            nn.ReLU(),
            nn.MaxPool2d(3, 2, 1),
            # nn.Dropout2d(dropout),

            nn.Conv2d(128, 256, 3, 1, 1),
            nn.BatchNorm2d(256),
            nn.ReLU(),
            nn.Conv2d(256, 256, 3, 1, 1),
            nn.BatchNorm2d(256),
            nn.ReLU(),
            nn.MaxPool2d(3, 2, 1),
            # nn.Dropout2d(dropout),

            nn.Conv2d(256, 512, 3, 1, 1),
            nn.BatchNorm2d(512),
            nn.ReLU(),
            nn.Conv2d(512, 512, 3, 1, 1),
            nn.BatchNorm2d(512),
            nn.ReLU(),
            nn.MaxPool2d(3, 2, 1),
            # nn.Dropout2d(dropout),

            nn.Conv2d(512, 512, 3, 1, 1),
            nn.BatchNorm2d(512),
            nn.ReLU(),
            nn.Conv2d(512, 512, 3, 1, 1),
            nn.BatchNorm2d(512),
            nn.ReLU(),
            nn.MaxPool2d(3, 2, 1),
            # nn.Dropout2d(dropout)
        )
        self.FC = nn.Linear(512, n_classes)
        print(self)

    def forward(self, x):
        """
        Performs forward pass of the input.
        Args:
            x: input to the network
        Returns:
            out: outputs of the network
        """
        if not isinstance(x, Tensor):
            x = Tensor(x)
        tmp = self.convLayers(x)
        return self.FC(tmp.view(-1, 512))

class CNN_ELU(nn.Module):
    def __init__(self, n_channels, n_classes):
        """
        Initializes CNN object.

        Args:
            n_channels: number of input channels
            n_classes: number of classes of the classification problem
        """
        super().__init__()
        self.convLayers = nn.Sequential(
            nn.Conv2d(n_channels, 64, 3, 1, 1),
            nn.BatchNorm2d(64),
            nn.ELU(),
            nn.MaxPool2d(3, 2, 1),
            nn.Dropout2d(0.1),

            nn.Conv2d(64, 128, 3, 1, 1),
            nn.BatchNorm2d(128),
            nn.ELU(),
            nn.MaxPool2d(3, 2, 1),
            nn.Dropout2d(0.2),

            nn.Conv2d(128, 256, 3, 1, 1),
            nn.BatchNorm2d(256),
            nn.ELU(),
            nn.Conv2d(256, 256, 3, 1, 1),
            nn.BatchNorm2d(256),
            nn.ELU(),
            nn.MaxPool2d(3, 2, 1),
            nn.Dropout2d(0.3),

            nn.Conv2d(256, 512, 3, 1, 1),
            nn.BatchNorm2d(512),
            nn.ELU(),
            nn.Conv2d(512, 512, 3, 1, 1),
            nn.BatchNorm2d(512),
            nn.ELU(),
            nn.MaxPool2d(3, 2, 1),
            nn.Dropout2d(0.4),

            nn.Conv2d(512, 512, 3, 1, 1),
            nn.BatchNorm2d(512),
            nn.ELU(),
            nn.Conv2d(512, 512, 3, 1, 1),
            nn.BatchNorm2d(512),
            nn.ELU(),
            nn.MaxPool2d(3, 2, 1),
            nn.Dropout2d(0.5)
        )
        self.FC = nn.Linear(512, n_classes)
        # print(self)

    def forward(self, x):
        """
        Performs forward pass of the input.
        Args:
            x: input to the network
        Returns:
            out: outputs of the network
        """
        if not isinstance(x, Tensor):
            x = Tensor(x)
        tmp = self.convLayers(x)
        return self.FC(tmp.view(-1, 512))
