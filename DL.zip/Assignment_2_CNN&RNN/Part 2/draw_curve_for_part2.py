from draw_curve import drawCurve
import matplotlib.pyplot as plt
import json
import numpy as np

task = input('select the one of the following tasks to be display:\n'
             '1.Loss Value 2.Training Accuracy 3.Test Accuracy\n')

folders = ('CNN_original', 'CNN_DA', 'CNN_dropout', 'CNN_dropout_ELU', 'MLP_for_CIFAR10')
colors = ('red', 'yellow', 'green', 'blue', 'purple')

if task == 'Loss Value':
    for i, fd in enumerate(folders):
        with open('./%s/loss_data.json' % folders[i], 'r') as f:
            data = np.array(json.load(f))
            plt.plot(range(1, 2001), data, color=colors[i], label = folders[i])
    plt.title('Loss')
    plt.legend(loc='upper right')
    plt.show()
elif task == 'Training Accuracy':
    for i, fd in enumerate(folders):
        if i < 4:
            with open('./%s/accu_data.json' % folders[i], 'r') as f:
                data = np.array(json.load(f))
                plt.plot(range(1, 2001, 10), data[:, 0], color=colors[i], label = folders[i])
        else:
            with open('./%s/train_accu.json' % folders[i], 'r') as f:
                data = json.load(f)
                plt.plot(range(1, 2001, 10), data, color=colors[i], label = folders[i])
    plt.title('Training Accuracy')
    plt.legend(loc='lower right')
    plt.show()
elif task == 'Test Accuracy':
    for i, fd in enumerate(folders):
        if i < 4:
            with open('./%s/accu_data.json' % folders[i], 'r') as f:
                data = np.array(json.load(f))
                plt.plot(range(1, 2001, 10), data[:, 1], color=colors[i], label = folders[i])
        else:
            with open('./%s/test_accu.json' % folders[i], 'r') as f:
                data = json.load(f)
                plt.plot(range(1, 2001, 10), data, color=colors[i], label = folders[i])
    plt.title('Test Accuracy')
    plt.legend(loc='lower right')
    plt.show()
else:
    print('Invalid Task')
