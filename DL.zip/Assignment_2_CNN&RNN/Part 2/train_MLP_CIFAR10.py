from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import argparse
import torch
import torchvision
from torchvision import transforms
from torch.utils.data.dataloader import DataLoader
from torch.nn import CrossEntropyLoss
from torch import optim
import time
import numpy as np
import os
from pytorch_mlp import MLP
import json
from draw_curve import drawCurve

# Default constants
LEARNING_RATE_DEFAULT = 1e-4
BATCH_SIZE_DEFAULT = 128
MAX_EPOCHS_DEFAULT = 2000
EVAL_FREQ_DEFAULT = 10
WEIGHT_PENAL_DEFAULT = 5e-4
USING_GPU_DEFAULT = True
DATA_AUGMENTATION_DEFAULT = True
OPTIMIZER_DEFAULT = 'ADAM'
THREADS_DEFAULT = 16
save_freq = 250
DNN_HIDDEN_UNITS_DEFAULT = '2048,4096,512'
SHOW_CURVE_DEFAULT = False

FLAGS = None

RESULT_PATH_DEFAULT = 'MLP_for_CIFAR10'

# transform = transforms.Compose(
#     [transforms.ToTensor(),
#      transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])

def accuracy(model, data_loader):
    """
    Computes the prediction accuracy, i.e., the average of correct predictions
    of the network.
    Args:
        predictions: 2D float array of size [number_of_data_samples, n_classes]
        labels: 2D int array of size [number_of_data_samples, n_classes] with one-hot encoding of ground-truth labels
    Returns:
        accuracy: scalar float, the accuracy of predictions.
    """
    model.eval()

    correct = torch.zeros(1).squeeze()
    total = torch.zeros(1).squeeze()

    if gpu:
        correct = correct.cuda()
        total = total.cuda()

    for i, (X, Y) in enumerate(data_loader):
        if gpu:
            X = X.cuda()
            Y = Y.cuda()

        output = model(X)

        prediction = torch.argmax(output, 1)
        correct += (prediction == Y).sum().float()
        total += len(Y)
    model.train()
    return float((correct / total).cpu())


def train(gpu=False):
    """
    Performs training and evaluation of MLP model.
    NOTE: You should the model on the whole test set each eval_freq iterations.
    """
    # YOUR TRAINING CODE GOES HERE

    # if show:

    model = MLP(3072, structure, 10)
    print('==============Model Initialized==============')
    print(model)
    gpu = gpu and torch.cuda.is_available()
    if gpu:
        model = model.cuda()
    loss_func = CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=lr, weight_decay=weight_penal)
    loss_data = []
    train_accu = []
    test_accu = []
    print('===============Training start================')
    start_time = time.time()

    for ep in range(max_steps):
        mean_loss = 0.0

        if ep == 100:
            optimizer = optim.Adam(model.parameters(), lr=lr/10, weight_decay=weight_penal)
        elif ep == 500:
            optimizer = optim.Adam(model.parameters(), lr=lr/100, weight_decay=weight_penal)

        for X, Y in train_loader:
            # print(Y)
            if gpu:
                X = X.cuda()
                Y = Y.cuda()
            optimizer.zero_grad()
            loss = loss_func(model(X), Y)
            loss.backward()
            optimizer.step()
            mean_loss += loss.item()
        mean_loss /= len(train_loader.dataset)
        loss_data.append(mean_loss)
        print('Epoch%d\tTraining Loss: %.8f, time=%.2f' % (ep + 1, mean_loss, time.time()-start_time))

        if not (ep+1) % eval_freq:
            train_accu.append(accuracy(model, original_train_loader))
            test_accu.append(accuracy(model, test_loader))
            print('Accuracy: train set%.1f%%, test set%.1f%%' % (train_accu[-1]*100, test_accu[-1]*100))

            if show:
                drawCurve(train_accu, test_accu, loss_data, ep)

        if not (ep+1) % save_freq:
            torch.save(model.state_dict(), './%s/CNN_%d_dict.pkl' % (result_path, ep + 1))
            with open('./%s/loss_data.json' % result_path, 'w') as f:
                json.dump(loss_data, f)
            with open('./%s/train_accu.json' % result_path, 'w') as f:
                json.dump(train_accu, f)
            with open('./%s/test_accu.json' % result_path, 'w') as f:
                json.dump(test_accu, f)
            t = int(time.time() - start_time)
            with open('./%s/Summary.txt' % result_path, 'w') as f:
                f.write('Total time:%d:%d:%d, Epochs:%d, Average time per epoch: %.1f' %
                        (t//3600, (t%3600)//60, t%60, ep+1, t/(ep+1)))

def main(gpu=False):
    """
    Main function
    """
    train(gpu)

if __name__ == '__main__':
    # Command line arguments
    parser = argparse.ArgumentParser()
    parser.add_argument('--learning_rate', type = float, default = LEARNING_RATE_DEFAULT,
                      help='Learning rate')
    parser.add_argument('--max_steps', type = int, default = MAX_EPOCHS_DEFAULT,
                      help='Number of steps to run trainer.')
    parser.add_argument('--batch_size', type = int, default = BATCH_SIZE_DEFAULT,
                      help='Batch size to run trainer.')
    parser.add_argument('--eval_freq', type=int, default=EVAL_FREQ_DEFAULT,
                        help='Frequency of evaluation on the test set')
    parser.add_argument('--using_gpu', type=bool, default=USING_GPU_DEFAULT,
                        help='Using GPU or not')
    parser.add_argument('--weight_penal', type=bool, default=WEIGHT_PENAL_DEFAULT,
                        help='Parameter of L2 regularization')
    parser.add_argument('--data_augmentation', type = bool, default = DATA_AUGMENTATION_DEFAULT,
                        help='Use data augmentation or not')
    parser.add_argument('--result_path', type=str, default=RESULT_PATH_DEFAULT,
                        help='Directory for storing result data and model')
    parser.add_argument('--threads', type=int, default=THREADS_DEFAULT,
                        help='How many sub threads will be used to process training data')
    parser.add_argument('--dnn_hidden_units', type = str, default = DNN_HIDDEN_UNITS_DEFAULT,
                      help='Comma separated list of number of units in each hidden layer')
    parser.add_argument('--show_curve', type = bool, default = SHOW_CURVE_DEFAULT,
                      help='Show accuracy and loss curve during ')

    FLAGS, unparsed = parser.parse_known_args()

    structure = [*map(int, FLAGS.dnn_hidden_units.split(','))]
    lr = FLAGS.learning_rate
    max_steps = FLAGS.max_steps
    batch_size = FLAGS.batch_size
    eval_freq = FLAGS.eval_freq
    gpu = FLAGS.using_gpu
    weight_penal = FLAGS.weight_penal
    data_augmentation = FLAGS.data_augmentation
    result_path = FLAGS.result_path
    threads = FLAGS.threads
    show = FLAGS.show_curve
    if data_augmentation:
        tsf = transforms.Compose([
            transforms.RandomApply([
                transforms.RandomChoice([
                    transforms.Resize(28),
                    transforms.Resize(24),
                    transforms.Resize(20)
                ]),
                transforms.RandomHorizontalFlip(),
                transforms.ColorJitter(brightness=0.5, contrast=0.5, hue=0.5),
                torchvision.transforms.RandomRotation(15),
                ], p=0.4),
            transforms.RandomChoice([
                transforms.RandomResizedCrop(32, (0.6, 1.0), ratio=(0.85, 1.2)),
                transforms.Resize(32)
            ]),
            transforms.ToTensor()
        ])
    else:
        tsf = transforms.ToTensor()

    train_set = torchvision.datasets.CIFAR10(
        root='./data', train=True, download=False, transform=tsf)
    train_loader = DataLoader(
        train_set, batch_size=batch_size, shuffle=True, num_workers=threads, pin_memory=gpu)

    original_train_set = torchvision.datasets.CIFAR10(
        root='./data', train=True, download=False, transform=transforms.ToTensor())
    original_train_loader = DataLoader(
        original_train_set, batch_size=batch_size, shuffle=True, num_workers=threads, pin_memory=gpu)


    test_set = torchvision.datasets.CIFAR10(
        root='./data', train=False, download=False, transform=transforms.ToTensor())
    test_loader = DataLoader(
        test_set, batch_size=batch_size, shuffle=False, num_workers=threads, pin_memory=gpu)



    main(gpu)
    # model = CNN(3, 10)
    # model = model.cuda()
    # accuracy(model, train_loader)
