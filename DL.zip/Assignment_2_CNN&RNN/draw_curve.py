import matplotlib.pyplot as plt

def drawCurve(train_accu, test_accu, loss, ep):
    _, ax1 = plt.subplots()
    ax2 = ax1.twinx()
    ax1.set_xlabel("Epoch")
    ax1.set_ylabel("Accuracy")
    ax2.set_ylabel("Loss")
    ax1.set_ylim(0.4, 1.0)
    ax2.set_ylim(0.016, 0.04)
    ax1.plot(range(10, ep + 1, 10), train_accu, 'y-', label='accuracy on train set')
    ax1.plot(range(10, ep + 1, 10), test_accu, 'b-', label='accuracy on test set')
    ax2.plot(range(1, ep + 1), loss, 'g-', label='loss')
    ax1.legend(loc='lower left')
    ax2.legend(loc='lower right')
    plt.show()

