import json
import matplotlib.pyplot as plt

if __name__ == '__main__':
    with open('./pytorch_loss.json', 'r') as f:
        loss = json.load(f)
    with open('./pytorch_train_accu.json', 'r') as f:
        trian_accu = json.load(f)
    with open('./pytorch_test_accu.json', 'r') as f:
        test_accu = json.load(f)

    x_axis = [i + 1 for i in range(0, 500)]

    plt.ylim(0.2, 0.95)
    plt.title('pytorch')
    plt.plot(x_axis, loss, '-b', label='loss', lw=1)
    plt.plot(x_axis, trian_accu, '-r', label='accuracy on train set', lw=1)
    plt.plot(x_axis, test_accu, '-y', label='accuracy on test set', lw=1)
    plt.legend()
    plt.savefig('pytorch_mlp_result.jpg')
    plt.show()

