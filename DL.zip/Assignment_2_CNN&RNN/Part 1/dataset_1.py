from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import torch.utils.data as data
from torch import Tensor
import json

class JsonDataset(data.Dataset):
    def __init__(self, dataFile, labelFile):
        with open(dataFile, 'r') as f:
            self.data = json.load(f)
        with open(labelFile, 'r') as f:
            self.labels = json.load(f)
        assert len(self.data) == len(self.labels)
        self.size = len(self.data)

    def __len__(self):
        return self.size

    def __getitem__(self, idx):
        return Tensor(self.data[idx]), int(0) if self.labels[idx][0] else int(1)
