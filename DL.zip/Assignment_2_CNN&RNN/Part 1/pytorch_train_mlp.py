from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import argparse
import numpy as np
import os
import json
import time
from pytorch_mlp import MLP
from torch import nn, optim
from torch.utils.data.dataloader import DataLoader
from dataset_1 import JsonDataset
from draw_curve import drawCurve

# Default constants
DNN_HIDDEN_UNITS_DEFAULT = '20'
LEARNING_RATE_DEFAULT = 1e-3
MAX_EPOCHS_DEFAULT = 500
EVAL_FREQ_DEFAULT = 10
SHOW_CURVE_DEFAULT = True

FLAGS = None

train_set = JsonDataset('./train_set/data.json', './train_set/label.json')
test_set = JsonDataset('./test_set/data.json', './test_set/label.json')
train_loader = DataLoader(train_set)
test_loader = DataLoader(test_set)


def para_init(m):
# 使用isinstance来判断m属于什么类型
    if isinstance(m, nn.Linear):
        m.weight.data.normal_(0.0, 0.0001)
        m.bias.data.fill_(0.2)


def accuracy(predictions, targets):
    """
    Computes the prediction accuracy, i.e., the average of correct predictions
    of the network.
    Args:
        predictions: 2D float array of size [number_of_data_samples, n_classes]
        labels: 2D int array of size [number_of_data_samples, n_classes] with one-hot encoding of ground-truth labels
    Returns:
        accuracy: scalar float, the accuracy of predictions.
    """
    assert len(predictions) == len(targets)
    total = len(predictions)
    correct = 0
    # print(predictions)
    for i in range(total):
        tar = int(targets[i])
        if predictions[i][tar] > predictions[i][(tar+1)%2]:
            correct+=1
    return correct/total

def train():
    print(structure)
    time.sleep(0.5)
    model = MLP(2, structure, 2)

    print(model)

    model.apply(para_init)

    loss_data = []
    train_accu = []
    test_accu = []

    # model.printPara()
    optimizer = optim.SGD(model.parameters(), lr=learning_rate)
    loss_func = nn.CrossEntropyLoss()
    loss_func = loss_func.cuda()
    for ep in range(max_steps):
        train_loss = 0.0
        for data, label in train_loader:
            optimizer.zero_grad()       # 清空上一步的残余更新参数值
            output = model(data)        # 得到预测值
            loss = loss_func(output, label)         # 计算两者的误差
            loss.backward()                         # 误差反向传播, 计算参数更新值
            optimizer.step()                        # 将参数更新值施加到 net 的 parameters 上
            train_loss += loss.item()
        train_loss = train_loss/len(train_loader.dataset)
        loss_data.append(train_loss)
        print('Epoch%d\tTraining Loss: %.6f' % (ep + 1, train_loss))

        # if not (ep+1)%eval_freq:
        #     drawCurve(train_accu, test_accu, loss_data, ep)
        tmp = np.array([[model(x).squeeze(), lb] for x, lb in train_loader])
        train_accu.append(accuracy(tmp[:, 0], tmp[:, 1]))
        tmp = np.array([[model(x).squeeze(), lb] for x, lb in test_loader])
        test_accu.append(accuracy(tmp[:, 0], tmp[:, 1]))

        print('Accuracy: train set%.1f%%, test set%.1f%%' % (train_accu[-1]*100, test_accu[-1]*100))
    # if show:
    return loss_data, train_accu, test_accu

    # YOUR TRAINING CODE GOES HERE

def experiment(runtimes=10):
    loss = [0.0]*max_steps
    train_accu = [0.0]*(max_steps)
    test_accu = [0.0]*(max_steps)
    for _ in range(runtimes):
        loss_data, train_accu_data, test_accu_data = train()
        for i in range(max_steps):
            loss[i] += loss_data[i]/runtimes
            train_accu[i] += train_accu_data[i]/runtimes
            test_accu[i] += test_accu_data[i]/runtimes
    with open('pytorch_loss.json', 'w') as f:
        json.dump(loss, f)
    with open('pytorch_train_accu.json', 'w') as f:
        json.dump(train_accu, f)
    with open('pytorch_test_accu.json', 'w') as f:
        json.dump(test_accu, f)


def main():
    """
    Main function
    """
    train()

if __name__ == '__main__':
    # Command line arguments
    parser = argparse.ArgumentParser()
    parser.add_argument('--dnn_hidden_units', type = str, default = DNN_HIDDEN_UNITS_DEFAULT,
                      help='Comma separated list of number of units in each hidden layer')
    parser.add_argument('--learning_rate', type = float, default = LEARNING_RATE_DEFAULT,
                      help='Learning rate')
    parser.add_argument('--max_steps', type = int, default = MAX_EPOCHS_DEFAULT,
                      help='Number of epochs to run trainer.')
    parser.add_argument('--eval_freq', type=int, default=EVAL_FREQ_DEFAULT,
                          help='Frequency of evaluation on the test set')
    # parser.add_argument('--show_curve', type = bool, default = SHOW_CURVE_DEFAULT,
    #                   help='Show accuracy and loss curve during ')
    FLAGS, unparsed = parser.parse_known_args()

    structure = [*map(int, FLAGS.dnn_hidden_units.split(','))]
    learning_rate = FLAGS.learning_rate
    max_steps = FLAGS.max_steps
    eval_freq = FLAGS.eval_freq
    show = FLAGS.show_curve
    experiment()
    # main()